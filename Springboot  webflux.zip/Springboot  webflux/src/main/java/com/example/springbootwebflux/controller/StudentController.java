package com.example.springbootwebflux.controller;

import com.example.springbootwebflux.model.GeneralResponse;
import com.example.springbootwebflux.model.Students;
import com.example.springbootwebflux.repository.StudentsRepository;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import java.util.HashMap;
import java.util.Map;

@RestController
@AllArgsConstructor
public class StudentController {

    @Autowired
    StudentsRepository studentsRepository;

    @PostMapping("/students")
    public Mono<ResponseEntity<Students>> addStudent(@RequestBody Students studentAdd) {
    studentAdd.setRegisteredOn(System.currentTimeMillis());
    studentAdd.setStatus(1);
    return studentsRepository.save(studentAdd).map(student -> {
        return new ResponseEntity<>(student, HttpStatus.CREATED);
    });
}

    @GetMapping("/students/{studentID}")
    public Mono<ResponseEntity<Students>> getStudent(@PathVariable Long studentID) {
        return studentsRepository.findById(studentID).map(student -> {
            return new ResponseEntity<>(student, HttpStatus.OK);
        });
    }

    @PutMapping("/student/{studentID}")
    Mono<ResponseEntity<Students>> updateStudents(@PathVariable Long studentID, @RequestBody Students newStudentData) {

        return studentsRepository.findById(studentID)
                .switchIfEmpty(Mono.error(new Exception("Student with ID " + studentID + " not found")))
                .flatMap(foundStudent -> {
                    foundStudent.setName(newStudentData.getName());

                    return studentsRepository.save(foundStudent).map(student -> {
                        return new ResponseEntity<>(student, HttpStatus.ACCEPTED);
                    });
                });



    }

    @PutMapping("/students/{studentID}")
    Mono<ResponseEntity<GeneralResponse<Students>>> updateStudent(@PathVariable Long studentID, @RequestBody Students newStudentData) {

        return studentsRepository.findById(studentID)
                .switchIfEmpty(Mono.error(new Exception(String.format("Student with ID %d not found", studentID))))
                .flatMap(foundStudent -> {
                    //here we are just updating the name. You can add others
                    foundStudent.setName(newStudentData.getName());

                    return studentsRepository.save(foundStudent);
                }).map(student -> {
                    Map<String, Students> data = new HashMap<>();
                    data.put("student", student);

                    return new ResponseEntity<>(
                            GeneralResponse.<Students>builder()
                                    .success(true)
                                    .message("Student updated successfully")
                                    .data(data)
                                    .build(),
                            HttpStatus.ACCEPTED
                    );
                }).onErrorResume(e -> {
                    return Mono.just(
                            new ResponseEntity<>(
                                    GeneralResponse.<Students>builder()
                                            .success(false)
                                            .message(e.getMessage())
                                            .build(),
                                    HttpStatus.NOT_FOUND
                            )
                    );
                });

    }

}
