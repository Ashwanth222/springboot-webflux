package com.example.springbootwebflux.repository;

import com.example.springbootwebflux.model.Students;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface StudentsRepository extends ReactiveCrudRepository<Students, Long> {
}
